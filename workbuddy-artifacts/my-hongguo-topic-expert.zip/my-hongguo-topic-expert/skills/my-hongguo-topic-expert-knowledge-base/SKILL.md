---
name: my-hongguo-topic-expert-knowledge-base
description: "Built-in knowledge base of the Hongguo short-drama topic-selection expert: 200 methodology and workflow references, 120 datasets, matrices and checklists, 110 fill-in delivery templates and 60 quick-reference cards, covering platform economics, genre-window scanning, hit-gene reverse engineering, character and relationship design, hook and cliffhanger engineering, title and cover strategy, production cost and break-even modelling, revenue scenario analysis and compliance pre-check (resource baseline: 2026-09)."
description_zh: "红果短剧选题专家内置知识库：200 卷方法论与工程化工序卡、120 卷数据清单与矩阵、110 卷可填充交付模板与 60 张速查卡，覆盖平台商业逻辑、赛道红利扫描、爆款基因逆向、人设与关系工程、钩子与卡点工程、剧名封面策略、成本与保本测算、收益情景推演与合规预检（资源库口径：2026-09）。"
description_en: "Built-in knowledge base of the Hongguo short-drama topic-selection expert: 200 methodology and workflow references, 120 datasets and matrices, 110 fill-in templates and 60 quick-reference cards, covering platform economics, genre-window scanning, hit-gene reverse engineering, character and relationship design, hook engineering, title and cover strategy, cost and break-even modelling, revenue scenarios and compliance pre-check (baseline: 2026-09)."
display_name: "红果短剧选题专家内置知识库"
display_name_en: "Hongguo Short-Drama Topic Expert Knowledge Base"
agent_created: true
version: 1.0.0
---

# 红果短剧选题专家 · 内置知识库

> 资源库口径：2026-09 ｜ 维护：月度自动进化 ｜ 本知识库为「红果短剧选题专家」专家的内嵌资源。

## 一、用途

本知识库为「红果短剧选题专家」提供可检索的方法论、数据集、交付模板与速查卡。**按需读取 1—3 个文件，禁止一次性全量加载。**

## 二、资源地图

| 目录 | 数量 | 内容 | 用法 |
|---|---|---|---|
| `references/` | 200 | 001—120 为方法论与深度工程细则；121—200 为工程化工序卡（适用场景/输入/步骤/输出/自检） | 设计方法论、标准工序、判据与自检 |
| `data/` | 120 | 平台事实、题材结构、赛道要素、拆解字段、清单与矩阵 | 查询对照、直接引用表格 |
| `templates/` | 110 | 选题卡、策划书、拆解表、钩子表、剧名矩阵、测算表、风险台账等 | 直接填充后交付 |
| `assets/cards/` | 60 | 主题速查卡（900×1250 图卡） | 人类阅读的速查图卡 |

## 三、索引文件

`agents/my-hongguo-topic-expert.md` 第九章提供全量文件索引（文件名与标题一一对应），可按编号或关键词直接定位。

## 四、时效纪律

- 引用本知识库内容时标注「资源库口径：2026-09」；
- 当前日期晚于 2026-09 时，先提示按平台当期公告与创作者后台复核，再由执行环境按检索关键词矩阵联网更新；
- 本知识库不发起任何网络请求；更新由月度自动进化流程完成，并在 `changelog.md` 记录；
- 平台分账口径、审核尺度与榜单规则一律以当期官方口径为准，本知识库不固化数值。

## 五、边界

本知识库不含任何凭证、密钥与用户隐私信息；不含可执行文件；所有内容为纯文本方法论与模板。涉及分账测算、版权与合规的结论一律标注须由制片方与法务确认。
